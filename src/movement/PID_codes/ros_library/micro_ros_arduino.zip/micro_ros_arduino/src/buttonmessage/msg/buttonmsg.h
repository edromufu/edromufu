// generated from rosidl_generator_c/resource/idl.h.em
// with input from buttonmessage:msg/Buttonmsg.idl
// generated code does not contain a copyright notice

#ifndef BUTTONMESSAGE__MSG__BUTTONMSG_H_
#define BUTTONMESSAGE__MSG__BUTTONMSG_H_

#include "buttonmessage/msg/detail/buttonmsg__struct.h"
#include "buttonmessage/msg/detail/buttonmsg__functions.h"
#include "buttonmessage/msg/detail/buttonmsg__type_support.h"

#endif  // BUTTONMESSAGE__MSG__BUTTONMSG_H_

// generated from rosidl_generator_c/resource/idl.h.em
// with input from control_msgs:action/SingleJointPosition.idl
// generated code does not contain a copyright notice

#ifndef CONTROL_MSGS__ACTION__SINGLE_JOINT_POSITION_H_
#define CONTROL_MSGS__ACTION__SINGLE_JOINT_POSITION_H_

#include "control_msgs/action/detail/single_joint_position__struct.h"
#include "control_msgs/action/detail/single_joint_position__functions.h"
#include "control_msgs/action/detail/single_joint_position__type_support.h"

#endif  // CONTROL_MSGS__ACTION__SINGLE_JOINT_POSITION_H_
